import json
from difflib import get_close_matches

def load_knowledge_base(file_path: str) -> dict:
    """Loads the knowledge base from a JSON file."""
    try:
        with open(file_path, 'r') as file:
            data = json.load(file)
        return data
    except FileNotFoundError:
        return {"intents": []}

def find_best_match(user_question: str, intents: list) -> str | None:
    """Finds the best matching intent for the user's question."""
    all_patterns = []
    pattern_to_intent = {}

    for intent in intents:
        for pattern in intent["patterns"]:
            all_patterns.append(pattern)
            pattern_to_intent[pattern] = intent

    # Use difflib to find the closest matching pattern
    matches = get_close_matches(user_question.lower(), all_patterns, n=1, cutoff=0.6)
    
    if matches:
        return pattern_to_intent[matches[0]]
    return None

def get_response(intent: dict) -> str:
    """Returns a response from the matched intent."""
    return intent["responses"][0]

def chatbot():
    knowledge_base = load_knowledge_base("dataset.json")
    print("🎓 EduBot: Hello! I'm here to help with your college queries. (Type 'quit' to exit)")

    while True:
        user_input = input("You: ")
        
        if user_input.lower() in ["quit", "exit", "bye"]:
            print("EduBot: Goodbye! Good luck with your studies! 👋")
            break

        best_intent = find_best_match(user_input, knowledge_base["intents"])

        if best_intent:
            response = get_response(best_intent)
            print(f"EduBot: {response}")
        else:
            print("EduBot: I'm not sure I understand. Can you please rephrase that? (e.g., 'scholarships', 'fees', 'admission')")

if __name__ == "__main__":
    chatbot()
