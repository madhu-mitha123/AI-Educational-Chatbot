# EduBot: AI-Powered Educational Assistant

## 1. Project Title
**EduBot: Intelligent Student Inquiry System**

## 2. Problem Statement
Educational institutions receive thousands of repetitive queries from students regarding admissions, scholarships, fees, and course details every year. Managing these manually is time-consuming for staff and leads to delayed responses for students.

## 3. Objective
To develop a simple, AI-powered chatbot that provides instant, automated responses to common student queries, improving efficiency and accessibility 24/7.

## 4. Tools & Technologies
- **Programming Language:** Python
- **Libraries:** 
    - `json` (for data storage)
    - `difflib` (for approximate string matching/NLP basic logic)
- **Interface:** Command Line Interface (CLI) / Simple Console

## 5. Simple Working Logic
1.  **Input:** User asks a question (e.g., "How do I apply for a scholarship?").
2.  **Processing:** The system cleans the text and compares it against a predefined dataset of questions using string similarity matching.
3.  **Search:** It looks for the question in the dataset with the highest similarity score.
4.  **Response:** If a match is found (above a certain threshold), it retrieves the corresponding answer; otherwise, it asks the user to rephrase.

## 6. Features
- **Admission Queries:** Info on dates, procedures, and requirements.
- **Scholarship Assistance:** Details on eligibility and application.
- **Fee Structure:** Instant info on tuition and other fees.
- **General FAQs:** Location, contact info, and campus facilities.
- **Error Handling:** politely handles unknown queries.

## 7. Sample Dataset (Examples)
| User Query | Bot Response |
| values | matches |
| "What is the admission procedure?" | " Admissions are open. You can apply online via our portal at www.college.edu/apply." |
| "Tell me about scholarships." | "We offer merit-based and sports scholarships. Visit the admin office for details." |
| "What are the course fees?" | "The annual fee for B.Tech is $5000 and for B.Sc is $3000." |
| "Where is the library?" | "The library is located in Block B, second floor." |
| "Contact number?" | "You can reach us at contact@college.edu or +123-456-7890." |

## 8. Outcome & Benefits
- **Instant Response:** Zero wait time for students.
- **24/7 Availability:** Works even after college hours.
- **Cost-Effective:** Reduces the need for dedicated support staff for basic queries.
- **Consistent Information:** Accurate and uniform answers for everyone.

## 9. Business / Education Sector Impact
This project demonstrates how automation can streamline administrative workflows in the education sector, reducing operational costs and enhancing the student experience. It serves as a foundation for scalable AI solutions in ed-tech.
